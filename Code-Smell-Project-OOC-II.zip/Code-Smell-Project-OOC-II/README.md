#  SPLIT_WISE

User
  Name :A,B,C
  Password :1111,2222,3333
